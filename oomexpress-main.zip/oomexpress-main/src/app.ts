import express, { Request, Response, NextFunction } from 'express';
import * as bodyParser from 'body-parser';
import compression from 'compression';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';

import userRouter from './routers/user';

import config from './config';

const app = express();
const port = config.port;

app.use(helmet());
app.use(cors({ origin: config.cors_whitelist }));
app.use(compression());
app.use(morgan('tiny'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use('/users', userRouter);

app.get('/knockknock', (req: Request, res: Response) => {
  return res.status(200).json({ message: 'Who is there?' });
});

app.get('/health', (req: Request, res: Response) => {
  return res.status(200).send();
});

app.listen(port, () => {
  console.log(`⚡ Express is running on ${port}`);
});
