# Node.js Express Application with REST API
This is Node.js Express Application with REST API

## Prerequisites
- nvm (Node Version Manager)
- Node.js and npm (comes with Node)

## Getting Started
1. Run `nvm install` to install the required Node version specified in the .nvmrc file.
2. Run `nvm use` to switch to the specified Node version in accordance with the .nvmrc file.
3. Run `npm install` to install all the project dependencies.
4. Create a new file named `.env` in the root directory by copying the content of `.env.template` and update the environment variables accordingly.
5. Run `npm run start:dev` to start the application in development mode or `npm run start` to start in production mode.

Please note that step 1 and 2 are only required if your system has nvm installed, otherwise you can skip those steps and use the version of Node.js that you have installed on your machine.

## Authorization
Access to most of the resource endpoints in this application is secured using an API key. To make requests to these endpoints, you must include the API key in the request header by specifying 'API-KEY' as the key and the actual API key as the value.

The API Key, which is used to authenticate and authorize access to the API, can be located in either the `.env` file or the `.env.template` file. These files typically contain sensitive information and should be kept secure.

## API Endpoints
- GET `/knockknock` Returns a message and status to confirm the API is working
- GET `/health` Returns a status for healthcheck purpose
- GET `/users` Returns a list of users
- GET `/users/:id` Returns a specific user with the given id
- POST `/users` Creates a new user with the data provided in the request body
- PUT `/users/:id` Updates a specific user with the given id and the data provided in the request body
- DELETE `/users/:id` Deletes a specific user with the given id

## Built With
- Node.js
- Express.js

## Author
- [@oomnk](https://github.com/oomnk)
