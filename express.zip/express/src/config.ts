import * as dotenv from 'dotenv';
import invariant from 'tiny-invariant';

dotenv.config();

invariant(process.env.PORT, 'PORT is required in environment variable');
invariant(process.env.API_KEY, 'API_KEY is required in environment variable');
invariant(
  process.env.CORS_WHITELIST,
  'CORS_WHITELIST is required in environment variable'
);

const config = {
  port: process.env.PORT,
  api_key: process.env.API_KEY,
  cors_whitelist: process.env.CORS_WHITELIST.split(','),
};

export default config;
