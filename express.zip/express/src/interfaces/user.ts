export interface User {
  id: string;
  fname: string;
  lname: string;
}
