import * as Joi from 'joi';

import { User } from '../interfaces/user';

const createUserSchema = Joi.object().keys({
  fname: Joi.string().required(),
  lname: Joi.string().required(),
});

const updateUserSchema = Joi.object().keys({
  fname: Joi.string(),
  lname: Joi.string(),
});

export const createUserValidator = (user: User) => {
  return createUserSchema.validate(user);
};

export const updateUserValidator = (user: Partial<User>) => {
  return updateUserSchema.validate(user);
};
