import express, { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';

import { User } from '../interfaces/user';

import {
  createUserValidator,
  updateUserValidator,
} from '../validators/userValidator';

import config from '../config';

const router = express.Router();

const mockUsers: User[] = [
  {
    id: '2baed972-e448-4402-9f6d-bf5573c89a51',
    fname: 'Varachit',
    lname: 'Wirunpat',
  },
  {
    id: 'ff7d5ac0-81dd-4ffc-9e5f-f28336e352d8',
    fname: 'Nichapat',
    lname: 'Komjit',
  },
];

router.use((req: Request, res: Response, next: NextFunction) => {
  const apiKey = req.get('API-Key');

  if (!apiKey || apiKey !== config.api_key) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  next();
});

// Get all users
router.get('/', (req: Request, res: Response) => {
  return res.status(200).json(mockUsers);
});

// Get a user
router.get('/:userId', (req: Request, res: Response) => {
  const { userId } = req.params;

  const user = mockUsers.find((user) => user.id === userId);

  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }
  return res.status(200).json(user);

  //   db.collection(userCollection).doc(userId).get()
  //     .then((user) => {
  //       if (!user.exists) {
  //         throw new Error('User not found');
  //       }
  //       res.status(200).json({ id: user.id, data: user.data() })
  //     })
  //     .catch((error) => res.status(500).send(error));
});

// Create a user
router.post('/', (req: Request, res: Response) => {
  const body = req.body;

  const { value, error } = createUserValidator(body);

  if (error) {
    return res.status(400).send(error.details[0]);
  }

  const createdUser = {
    id: uuidv4(),
    fname: body.fname,
    lname: body.lname,
  };

  mockUsers.push(createdUser);
  return res.status(200).json({ message: 'User successfully created!' });
});

// Update a user
router.put('/:userId', async (req: Request, res: Response) => {
  const userId = req.params.userId;
  const body = req.body;

  const { value, error } = updateUserValidator(body);

  const userIndex = mockUsers.findIndex((user) => user.id === userId);

  if (!userIndex) {
    return res.status(404).json({ message: 'User not found' });
  }

  Object.entries(body).forEach(
    ([key, value]) => (mockUsers[userIndex][key] = value)
  );

  return res.status(200).json({ message: 'User succesfully updated!' });

  //   await db.collection(userCollection).doc(userId).set(body, { merge: true })
  //     .then(() => res.status(200).send('Update user successfully!'))
  //     .catch((error) => res.status(500).send(error));
  //     // 500 : Internal Error
});

// Delete a user
router.delete('/:userId', (req: Request, res: Response) => {
  const userId = req.params.userId;

  const userIndex = mockUsers.findIndex((user) => user.id === userId);

  if (!userIndex) {
    return res.status(404).json({ message: 'User not found' });
  }

  mockUsers.splice(userIndex, 1);
  return res.status(200).json({ message: 'User succesfully deleted!' });

  //   db.collection(userCollection).doc(req.params.userId).delete()
  //     .then(() => res.status(204).send('Document successfully deleted!'))
  //     .catch(function (error) {
  //       res.status(500).send(error);
  //     })
});

export default router;
